#include <stdio.h>

int main()
{
  int ch;
  while((ch=getc(stdin))!=-1)
  {
  }
}
