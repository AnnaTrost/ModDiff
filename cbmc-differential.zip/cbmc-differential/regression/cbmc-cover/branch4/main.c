int main()
{
  // no branch, but we want branch coverage
  // to imply 'function entry coverage'
  int x;
  x++;
}
