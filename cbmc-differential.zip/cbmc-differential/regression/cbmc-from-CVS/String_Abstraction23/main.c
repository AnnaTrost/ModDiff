#include <string.h>

int main()
{
  char msg[100]="abc";
  strlen(msg);

  return 0;
}
