int main()
{
  // should fail
  int *p=p;
  *p=0;
}
