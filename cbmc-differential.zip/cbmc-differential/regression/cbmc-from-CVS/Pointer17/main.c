int main()
{
  int **p;
  int *q;
  int i;
  q=&i;
  p=&q;
 
 
  **p=1;
}
