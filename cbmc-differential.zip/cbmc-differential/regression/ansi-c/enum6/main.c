enum A foo;

enum A
{
  V=1
};

enum A foo=V;

int main()
{
  return 0;
}
