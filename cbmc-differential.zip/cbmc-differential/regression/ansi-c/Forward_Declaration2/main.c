typedef struct list List;

int main() {
	List l;
}

struct list {
	int x;
};
