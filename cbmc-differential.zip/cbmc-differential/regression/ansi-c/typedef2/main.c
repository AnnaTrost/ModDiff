// Debian package ltrace
typedef unsigned int uint;

int main()
{
  goto uint;
uint: ;

  return 0;
}
