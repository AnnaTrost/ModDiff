typedef struct list List;

struct list {
	int x;
	int y;
};

int main() {
}
