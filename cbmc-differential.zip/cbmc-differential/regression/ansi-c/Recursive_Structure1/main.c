typedef struct list {
	struct list *next;
	int data;
} List;

int main() {
}
