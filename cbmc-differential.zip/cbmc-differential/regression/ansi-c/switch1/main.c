int main ()
{
  switch (0) case 0: case ( sizeof (long long) == 4) :;
  ;
  return 0;
}
