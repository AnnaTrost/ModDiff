static void foo()
{
  enum {
    COL_CUR,
    COL_CHG,
    COL_AVG,
    COL_MA10,
    COL_MA100,
    COL_MA1000,
    COL_LAST
  } col;
}

static void bar()
{
  enum {
    COL_CUR,
    COL_CHG,
    COL_AVG,
    COL_MA10,
    COL_MA100,
    COL_MA1000,
    COL_LAST
  } col;
}

int main()
{
  return 0;
}
