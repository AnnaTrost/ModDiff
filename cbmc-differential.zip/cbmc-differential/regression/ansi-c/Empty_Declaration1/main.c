int blah(void);
; // empty!

struct some
{
  ; // empty
};

int main() {
}
