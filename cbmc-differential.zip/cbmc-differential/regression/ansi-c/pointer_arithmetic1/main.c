int main()
{
  int *x;
  long o;
  if(x + o == x + 4)
    return 0;

  return 1;
}
