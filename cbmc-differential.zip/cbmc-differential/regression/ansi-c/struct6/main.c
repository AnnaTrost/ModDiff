struct _node {
    struct _node next;
} node;

int main(){
}
