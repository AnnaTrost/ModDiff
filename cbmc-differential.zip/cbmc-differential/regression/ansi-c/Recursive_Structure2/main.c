void anthy_make_word_list_all(void)
{
  struct depword_ent {
    struct depword_ent *next;
    int from;
  } *head, *de;
}

int main()
{
  anthy_make_word_list_all();

  return 0;
}

