int test;

int test = 0;

int main() {
}
