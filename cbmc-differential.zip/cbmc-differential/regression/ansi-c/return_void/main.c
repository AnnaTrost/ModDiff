void f()
{
}

void g()
{
  return f();
}

int main()
{
  g();
}
