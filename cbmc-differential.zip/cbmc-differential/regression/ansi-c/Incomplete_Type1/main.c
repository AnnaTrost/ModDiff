typedef struct list List;

int main() {
	List l;
}
