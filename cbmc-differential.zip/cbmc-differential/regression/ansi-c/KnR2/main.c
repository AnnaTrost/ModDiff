enum accept_stat
{
  V1
};

static void accepted(acpt_stat, x)
register enum accept_stat acpt_stat;
register int x;
{
}

int main()
{
}

