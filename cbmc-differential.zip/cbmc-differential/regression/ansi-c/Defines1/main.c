#ifdef NEW_DEFINE
  // Ok!
#else
  // define is missing
  #error "NEW_DEFINE is missing"
#endif

int main()
{
}
