int main()
{
  unsigned long __cil_tmp245;
  unsigned char (   (*__cil_tmp246))[4096];
  __cil_tmp246 = (unsigned char (   (*))[4096])__cil_tmp245;

  return 0;
}

