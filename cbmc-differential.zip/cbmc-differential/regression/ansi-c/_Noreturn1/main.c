#ifdef __GNUC__
extern _Noreturn void foo();
#endif

int main()
{
}
