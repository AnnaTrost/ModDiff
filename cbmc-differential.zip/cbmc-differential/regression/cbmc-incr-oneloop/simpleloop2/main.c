int main()
{
  int x;
  for(unsigned i = 0;i<5;i++) x--;
  assert(x!=0);
}
